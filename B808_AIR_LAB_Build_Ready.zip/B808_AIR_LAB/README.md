# B808 AIR LAB 1.0 (source release candidate, unverified)

An original JUCE C++ harmonic air enhancer, inspired by general analog exciter techniques. Not affiliated with Slate Digital, Universal Audio, Apple or Sony. No proprietary plugin source or visual assets are included.

## Features
- Mid Air and High Air parallel nonlinear excitation paths
- Input, Trim, Mix, Analog Character and Link controls
- 1x, 2x, 4x oversampling quality selection (quality changes take effect after the host re-prepares audio, such as reopening/reloading the plugin)
- Program-dependent envelope control, DC suppression, parameter smoothing
- Host-automatable parameters, state save/restore, mono/stereo support
- Input/output peak meters and original dark studio interface
- VST3 and standalone targets; AU target on macOS

## Build
Prerequisites: CMake 3.22+, C++17 compiler, Git, and JUCE dependencies appropriate for your OS. The CMake project fetches JUCE 8.0.10 from GitHub. An internet connection is required on first configure.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release -j 4
```

On Windows, use a compatible Visual Studio generator; on macOS use Xcode or Apple Clang. Output artifacts are placed under `build/B808AirLab_artefacts` and, on macOS, `build/B808AirLabAU_artefacts`.

## Important limits
This package is **source code**, not an installer or precompiled plugin. It has not been compiled, scanned, listened to or measured in this environment, at the user's request. It is not possible to guarantee that it builds on all target platforms or sounds like a commercial reference without verification. Oversampling changes need a processor re-prepare, and hard bypass does not currently delay-compensate the bypassed path. Link is implemented as an editor interaction and does not automatically mirror host automation. There is no factory preset library or installer in this package.

## Audio design
Band-selective excitation uses two high-pass-like branches and level-dependent asymmetric waveshaping with dynamic attenuation, blended back into the original path. This is an independent DSP implementation, not a recreation of undocumented commercial algorithms.

## Automated Windows/macOS compilation
This project now includes `.github/workflows/build.yml`. Upload the source to a GitHub repository and open **Actions → Build B808 AIR LAB → Run workflow**. Download the Windows and macOS artifacts from the completed workflow. This is a compilation workflow, not audio testing or release certification. JUCE downloads during the build. The resulting macOS binaries are unsigned and may require signing/notarization for public distribution.

The project has **not** been compiled here because this environment cannot reach GitHub to fetch JUCE. Build success is therefore not guaranteed. Exact Fresh Air sonic matching cannot be established without reference measurements. Review JUCE AGPL/commercial licensing before distribution.
