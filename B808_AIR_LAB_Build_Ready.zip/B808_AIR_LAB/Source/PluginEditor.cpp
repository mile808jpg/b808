#include "PluginEditor.h"
#include <cmath>

namespace {
constexpr auto amber = juce::Colour (0xffffac51);
constexpr auto background = juce::Colour (0xff17191d);
constexpr auto pale = juce::Colour (0xffe9e8e5);
constexpr auto muted = juce::Colour (0xff999b9f);
}

void B808AirLabAudioProcessorEditor::DialLookAndFeel::drawRotarySlider
    (juce::Graphics& g, int x, int y, int w, int h, float pos, float start, float end, juce::Slider&)
{
    auto bounds = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h).reduced (9.0f);
    const auto diameter = juce::jmin (bounds.getWidth(), bounds.getHeight());
    auto circle = bounds.withSizeKeepingCentre (diameter, diameter);
    const auto center = circle.getCentre();
    const float r = diameter * 0.5f;
    const float angle = start + pos * (end - start);
    juce::Path track;
    track.addCentredArc (center.x, center.y, r - 4, r - 4, 0, start, end, true);
    g.setColour (juce::Colour (0xff45474b)); g.strokePath (track, juce::PathStrokeType (4.0f));
    juce::Path active;
    active.addCentredArc (center.x, center.y, r - 4, r - 4, 0, start, angle, true);
    g.setColour (amber); g.strokePath (active, juce::PathStrokeType (4.5f));
    auto face = circle.reduced (12.0f);
    g.setColour (juce::Colours::black.withAlpha (0.6f)); g.fillEllipse (face.translated (0, 3));
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff4a4d51), face.getX(), face.getY(),
                                             juce::Colour (0xff16181b), face.getRight(), face.getBottom(), false));
    g.fillEllipse (face);
    g.setColour (juce::Colour (0xff777a7e)); g.drawEllipse (face, 1.3f);
    const float pointerLength = face.getWidth() * 0.32f;
    juce::Point<float> pointerEnd (center.x + std::sin (angle) * pointerLength,
                                   center.y - std::cos (angle) * pointerLength);
    g.setColour (pale); g.drawLine (center.x, center.y, pointerEnd.x, pointerEnd.y, 3.8f);
    g.fillEllipse (center.x - 2.5f, center.y - 2.5f, 5, 5);
}

B808AirLabAudioProcessorEditor::B808AirLabAudioProcessorEditor (B808AirLabAudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p)
{
    setLookAndFeel (&look);
    auto setup = [this] (juce::Slider& slider, juce::Label& label, juce::Label& value, const juce::String& name)
    {
        slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
        slider.setRotaryParameters (juce::MathConstants<float>::pi * 1.25f,
                                    juce::MathConstants<float>::pi * 2.75f, true);
        addAndMakeVisible (slider);
        label.setText (name, juce::dontSendNotification);
        label.setJustificationType (juce::Justification::centred);
        label.setColour (juce::Label::textColourId, pale);
        label.setFont (juce::Font (juce::FontOptions (16.0f, juce::Font::bold)));
        addAndMakeVisible (label);
        value.setJustificationType (juce::Justification::centred);
        value.setColour (juce::Label::textColourId, muted);
        value.setFont (juce::Font (juce::FontOptions (13.0f)));
        addAndMakeVisible (value);
    };
    setup (mid, midLabel, midValue, "MID AIR");
    setup (high, highLabel, highValue, "HIGH AIR");
    setup (trim, trimLabel, trimValue, "TRIM");
    setup (mix, mixLabel, mixValue, "MIX");
    setup (input, inputLabel, inputValue, "INPUT");
    setup (analog, analogLabel, analogValue, "ANALOG");
    quality.addItemList ({ "ECO 1x", "STANDARD 2x", "HIGH 4x" }, 1);
    quality.setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff181a1e));
    quality.setColour (juce::ComboBox::textColourId, pale);
    addAndMakeVisible (quality);
    qualityLabel.setText ("QUALITY", juce::dontSendNotification);
    qualityLabel.setJustificationType (juce::Justification::centred);
    qualityLabel.setColour (juce::Label::textColourId, muted);
    addAndMakeVisible (qualityLabel);
    midAttach = std::make_unique<SliderAttachment> (p.parameters, "MID", mid);
    highAttach = std::make_unique<SliderAttachment> (p.parameters, "HIGH", high);
    trimAttach = std::make_unique<SliderAttachment> (p.parameters, "TRIM", trim);
    mixAttach = std::make_unique<SliderAttachment> (p.parameters, "MIX", mix);
    inputAttach = std::make_unique<SliderAttachment> (p.parameters, "INPUT", input);
    analogAttach = std::make_unique<SliderAttachment> (p.parameters, "ANALOG", analog);
    qualityAttach = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (p.parameters, "QUALITY", quality);
    linkAttach = std::make_unique<ButtonAttachment> (p.parameters, "LINK", link);
    bypassAttach = std::make_unique<ButtonAttachment> (p.parameters, "BYPASS", bypass);
    for (auto* button : { &link, &bypass })
    {
        addAndMakeVisible (*button);
        button->setColour (juce::ToggleButton::textColourId, pale);
        button->setColour (juce::ToggleButton::tickColourId, amber);
    }
    // Link is a UI gesture: moving either Air knob also moves the other while enabled.
    mid.onValueChange = [this]
    {
        if (! linking && link.getToggleState())
        {
            juce::ScopedValueSetter<bool> guard (linking, true);
            high.setValue (mid.getValue(), juce::sendNotificationSync);
        }
    };
    high.onValueChange = [this]
    {
        if (! linking && link.getToggleState())
        {
            juce::ScopedValueSetter<bool> guard (linking, true);
            mid.setValue (high.getValue(), juce::sendNotificationSync);
        }
    };
    setSize (860, 610);
    startTimerHz (25);
}

B808AirLabAudioProcessorEditor::~B808AirLabAudioProcessorEditor() { setLookAndFeel (nullptr); }

void B808AirLabAudioProcessorEditor::paint (juce::Graphics& g)
{
    auto b = getLocalBounds();
    g.fillAll (background);
    g.setColour (juce::Colour (0xff22252a)); g.fillRoundedRectangle (b.toFloat().reduced (9), 13);
    g.setColour (juce::Colour (0xff53565b)); g.drawRoundedRectangle (b.toFloat().reduced (9), 13, 1);
    g.setColour (juce::Colour (0xff111317)); g.fillRect (14, 14, getWidth() - 28, 66);
    g.setColour (pale);
    g.setFont (juce::Font (juce::FontOptions (25.0f, juce::Font::bold)));
    g.drawText ("B808", 36, 22, 150, 45, juce::Justification::centredLeft);
    g.setFont (juce::Font (juce::FontOptions (17.0f)));
    g.drawText ("AIR LAB", 325, 24, 210, 26, juce::Justification::centred);
    g.setColour (muted);
    g.setFont (juce::Font (juce::FontOptions (10.5f)));
    g.drawText ("HARMONIC AIR ENHANCER", 310, 49, 240, 18, juce::Justification::centred);
    g.setColour (juce::Colour (0xff44464b));
    g.drawLine (32, 382, 828, 382, 1);
    g.setColour (amber.withAlpha (0.75f));
    g.fillRoundedRectangle (juce::Rectangle<float> (32, 79, getWidth() - 64.0f, 2), 1);
    g.setColour (muted);
    g.setFont (juce::Font (juce::FontOptions (11.0f)));
    g.drawText ("B808 AUDIO  •  HARMONIC AIR ENHANCER", 240, 574, 380, 17, juce::Justification::centred);
    drawMeter (g, { 45, 176, 35, 151 }, processor.inputPeak.load(), "IN");
    drawMeter (g, { 780, 176, 35, 151 }, processor.outputPeak.load(), "OUT");
}

void B808AirLabAudioProcessorEditor::drawMeter (juce::Graphics& g, juce::Rectangle<float> r, float peak, const juce::String& name)
{
    g.setColour (muted); g.setFont (juce::Font (juce::FontOptions (13.0f)));
    g.drawText (name, (int) r.getX() - 10, (int) r.getY() - 28, 55, 22, juce::Justification::centred);
    g.setColour (juce::Colours::black.withAlpha (0.65f)); g.fillRoundedRectangle (r, 4);
    const float dB = juce::Decibels::gainToDecibels (peak, -60.0f);
    const float amount = juce::jlimit (0.0f, 1.0f, (dB + 60.0f) / 60.0f);
    auto fill = r.reduced (5); fill.removeFromTop (fill.getHeight() * (1.0f - amount));
    g.setColour (amber); g.fillRoundedRectangle (fill, 2);
    g.setColour (juce::Colour (0xff57595d)); g.drawRoundedRectangle (r, 4, 1);
}

void B808AirLabAudioProcessorEditor::resized()
{
    mid.setBounds (125, 137, 240, 214);
    high.setBounds (495, 137, 240, 214);
    midLabel.setBounds (160, 342, 170, 28);
    highLabel.setBounds (530, 342, 170, 28);
    midValue.setBounds (204, 317, 80, 24);
    highValue.setBounds (574, 317, 80, 24);
    link.setBounds (390, 248, 82, 34);
    trim.setBounds (230, 396, 100, 74);
    trimLabel.setBounds (231, 387, 98, 20);
    trimValue.setBounds (237, 457, 86, 18);
    mix.setBounds (530, 396, 100, 74);
    mixLabel.setBounds (531, 387, 98, 20);
    mixValue.setBounds (537, 457, 86, 18);
    input.setBounds (75, 396, 100, 74);
    inputLabel.setBounds (76, 387, 98, 20);
    inputValue.setBounds (82, 457, 86, 18);
    analog.setBounds (685, 396, 100, 74);
    analogLabel.setBounds (686, 387, 98, 20);
    analogValue.setBounds (692, 457, 86, 18);
    qualityLabel.setBounds (325, 503, 210, 20);
    quality.setBounds (326, 526, 208, 30);
    bypass.setBounds (735, 28, 102, 35);
}

void B808AirLabAudioProcessorEditor::timerCallback()
{
    midValue.setText (juce::String (mid.getValue(), 0), juce::dontSendNotification);
    highValue.setText (juce::String (high.getValue(), 0), juce::dontSendNotification);
    trimValue.setText (juce::String (trim.getValue(), 1) + " dB", juce::dontSendNotification);
    mixValue.setText (juce::String (mix.getValue(), 0) + " %", juce::dontSendNotification);
    inputValue.setText (juce::String (input.getValue(), 1) + " dB", juce::dontSendNotification);
    analogValue.setText (juce::String (analog.getValue(), 0) + " %", juce::dontSendNotification);
    repaint();
}
