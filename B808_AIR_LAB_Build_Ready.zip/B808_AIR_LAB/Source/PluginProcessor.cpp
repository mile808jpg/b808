#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

B808AirLabAudioProcessor::B808AirLabAudioProcessor()
    : AudioProcessor (BusesProperties().withInput ("Input", juce::AudioChannelSet::stereo(), true)
                                        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      parameters (*this, nullptr, "B808_STATE", makeLayout()) {}

juce::AudioProcessorValueTreeState::ParameterLayout B808AirLabAudioProcessor::makeLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    layout.add (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "MID", 1 }, "Mid Air", 0.0f, 100.0f, 25.0f));
    layout.add (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "HIGH", 1 }, "High Air", 0.0f, 100.0f, 25.0f));
    layout.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { "LINK", 1 }, "Link", false));
    layout.add (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "TRIM", 1 }, "Trim", -18.0f, 18.0f, 0.0f));
    layout.add (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "MIX", 1 }, "Mix", 0.0f, 100.0f, 100.0f));
    layout.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { "BYPASS", 1 }, "Bypass", false));
    layout.add (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "INPUT", 1 }, "Input", -18.0f, 18.0f, 0.0f));
    layout.add (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "ANALOG", 1 }, "Analog Character", 0.0f, 100.0f, 35.0f));
    layout.add (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { "QUALITY", 1 }, "Quality", juce::StringArray { "Eco (1x)", "Standard (2x)", "High (4x)" }, 2));
    return layout;
}

bool B808AirLabAudioProcessor::isBusesLayoutSupported (const BusesLayout& layout) const
{
    auto out = layout.getMainOutputChannelSet();
    return (out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo())
           && layout.getMainInputChannelSet() == out;
}

void B808AirLabAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;
    for (auto& channel : channels) channel = {};
    const auto quality = (int) *parameters.getRawParameterValue ("QUALITY");
    oversamplingFactor = quality == 0 ? 1 : (quality == 1 ? 2 : 4);
    oversampler.reset();
    if (oversamplingFactor > 1)
    {
        oversampler = std::make_unique<juce::dsp::Oversampling<float>>
            (2, quality == 1 ? 1 : 2,
             juce::dsp::Oversampling<float>::filterHalfBandPolyphaseIIR, true, true);
        oversampler->initProcessing ((size_t) juce::jmax (1, samplesPerBlock));
        oversampler->reset();
        setLatencySamples ((int) std::ceil (oversampler->getLatencyInSamples()));
    }
    else setLatencySamples (0);
    for (auto* smoother : { &midSmooth, &highSmooth, &mixSmooth, &trimSmooth, &inputSmooth, &analogSmooth })
        smoother->reset (sampleRate * oversamplingFactor, 0.025);
    midSmooth.setCurrentAndTargetValue (*parameters.getRawParameterValue ("MID"));
    highSmooth.setCurrentAndTargetValue (*parameters.getRawParameterValue ("HIGH"));
    mixSmooth.setCurrentAndTargetValue (*parameters.getRawParameterValue ("MIX"));
    trimSmooth.setCurrentAndTargetValue (*parameters.getRawParameterValue ("TRIM"));
    inputSmooth.setCurrentAndTargetValue (*parameters.getRawParameterValue ("INPUT"));
    analogSmooth.setCurrentAndTargetValue (*parameters.getRawParameterValue ("ANALOG"));
    inputPeak.store (0); outputPeak.store (0);
}

void B808AirLabAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    for (int c = juce::jmin (2, buffer.getNumChannels()); c < buffer.getNumChannels(); ++c)
        buffer.clear (c, 0, buffer.getNumSamples());
    if (buffer.getNumSamples() == 0) return;
    midSmooth.setTargetValue (*parameters.getRawParameterValue ("MID"));
    highSmooth.setTargetValue (*parameters.getRawParameterValue ("HIGH"));
    mixSmooth.setTargetValue (*parameters.getRawParameterValue ("MIX"));
    trimSmooth.setTargetValue (*parameters.getRawParameterValue ("TRIM"));
    inputSmooth.setTargetValue (*parameters.getRawParameterValue ("INPUT"));
    analogSmooth.setTargetValue (*parameters.getRawParameterValue ("ANALOG"));

    float peakIn = 0.0f;
    for (int c = 0; c < juce::jmin (2, buffer.getNumChannels()); ++c)
        peakIn = juce::jmax (peakIn, buffer.getMagnitude (c, 0, buffer.getNumSamples()));
    inputPeak.store (juce::jmax (peakIn, inputPeak.load() * 0.85f));

    if (*parameters.getRawParameterValue ("BYPASS") > 0.5f)
    {
        outputPeak.store (juce::jmax (peakIn, outputPeak.load() * 0.85f));
        return;
    }
    juce::dsp::AudioBlock<float> block (buffer);
    if (oversampler != nullptr)
    {
        auto upsampled = oversampler->processSamplesUp (block);
        processAudio (upsampled, (float) (currentSampleRate * oversamplingFactor), true);
        oversampler->processSamplesDown (block);
    }
    else processAudio (block, (float) currentSampleRate, false);
    float peakOut = 0.0f;
    for (int c = 0; c < juce::jmin (2, buffer.getNumChannels()); ++c)
        peakOut = juce::jmax (peakOut, buffer.getMagnitude (c, 0, buffer.getNumSamples()));
    outputPeak.store (juce::jmax (peakOut, outputPeak.load() * 0.85f));
}

void B808AirLabAudioProcessor::processAudio (juce::dsp::AudioBlock<float>& block, float sr, bool)
{
    const int count = (int) block.getNumSamples();
    const int channelCount = juce::jmin (2, (int) block.getNumChannels());
    const float midAlpha = std::exp (-2.0f * juce::MathConstants<float>::pi * 2600.0f / sr);
    const float highAlpha = std::exp (-2.0f * juce::MathConstants<float>::pi * 7600.0f / sr);
    const float attack = std::exp (-1.0f / (0.003f * sr));
    const float release = std::exp (-1.0f / (0.075f * sr));
    const float dcAlpha = std::exp (-2.0f * juce::MathConstants<float>::pi * 18.0f / sr);
    for (int i = 0; i < count; ++i)
    {
        const float mid = midSmooth.getNextValue() * 0.01f;
        const float high = highSmooth.getNextValue() * 0.01f;
        const float mix = mixSmooth.getNextValue() * 0.01f;
        const float trim = juce::Decibels::decibelsToGain (trimSmooth.getNextValue());
        const float input = juce::Decibels::decibelsToGain (inputSmooth.getNextValue());
        const float character = analogSmooth.getNextValue() * 0.01f;
        for (int c = 0; c < channelCount; ++c)
        {
            auto& st = channels[c];
            auto* data = block.getChannelPointer ((size_t) c);
            const float dry = data[i];
            const float x = dry * input;
            st.midLow1 = (1.0f - midAlpha) * x + midAlpha * st.midLow1;
            st.midLow2 = (1.0f - midAlpha) * st.midLow1 + midAlpha * st.midLow2;
            st.highLow1 = (1.0f - highAlpha) * x + highAlpha * st.highLow1;
            st.highLow2 = (1.0f - highAlpha) * st.highLow1 + highAlpha * st.highLow2;
            const float midBand = x - st.midLow2;
            const float highBand = x - st.highLow2;
            auto excite = [&] (float band, float amount, float& envelope, float& dc, float drive)
            {
                const float mag = std::abs (band);
                const float coefficient = mag > envelope ? attack : release;
                envelope = coefficient * envelope + (1.0f - coefficient) * mag;
                const float control = 1.0f / (1.0f + 3.5f * envelope);
                const float v = band * (drive + character * 0.8f);
                const float saturated = std::tanh (v + character * 0.16f * v * v);
                // Subtract small-signal gain so the nonlinear branch emphasizes generated harmonics.
                const float harmonics = saturated - (drive + character * 0.8f) * band;
                dc = dcAlpha * dc + (1.0f - dcAlpha) * harmonics;
                return amount * control * (0.20f * band + 0.42f * (harmonics - dc));
            };
            const float enhancement = excite (midBand, mid, st.midEnvelope, st.dcMid, 1.5f)
                                    + excite (highBand, high, st.highEnvelope, st.dcHigh, 1.3f);
            // Preserve the input-gained dry path and mix only the parallel enhancement.
            data[i] = (x + mix * enhancement) * trim;
        }
    }
}

void B808AirLabAudioProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    auto state = parameters.copyState();
    if (auto xml = state.createXml()) copyXmlToBinary (*xml, dest);
}
void B808AirLabAudioProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (parameters.state.getType()))
            parameters.replaceState (juce::ValueTree::fromXml (*xml));
}
juce::AudioProcessorEditor* B808AirLabAudioProcessor::createEditor() { return new B808AirLabAudioProcessorEditor (*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new B808AirLabAudioProcessor(); }
