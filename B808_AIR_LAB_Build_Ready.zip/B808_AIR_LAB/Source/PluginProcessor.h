#pragma once
#include <JuceHeader.h>
#include <atomic>

class B808AirLabAudioProcessor final : public juce::AudioProcessor
{
public:
    B808AirLabAudioProcessor();
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "B808 AIR LAB"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return "Default"; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;
    bool isBusesLayoutSupported (const BusesLayout&) const override;

    juce::AudioProcessorValueTreeState parameters;
    std::atomic<float> inputPeak { 0.0f }, outputPeak { 0.0f };
    static juce::AudioProcessorValueTreeState::ParameterLayout makeLayout();

private:
    struct ChannelState
    {
        float midLow1 = 0.0f, midLow2 = 0.0f;
        float highLow1 = 0.0f, highLow2 = 0.0f;
        float midEnvelope = 0.0f, highEnvelope = 0.0f;
        float dcMid = 0.0f, dcHigh = 0.0f;
        float midDcIn = 0.0f, highDcIn = 0.0f;
        float midPrev = 0.0f, highPrev = 0.0f;
    };
    ChannelState channels[2];
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> midSmooth, highSmooth, mixSmooth, trimSmooth, inputSmooth, analogSmooth;
    double currentSampleRate = 44100.0;
    std::unique_ptr<juce::dsp::Oversampling<float>> oversampler;
    int oversamplingFactor = 4;
    void processAudio (juce::dsp::AudioBlock<float>& block, float sampleRate, bool oversampled);
    std::atomic<float> inputPeakL {0.0f}, inputPeakR {0.0f}, outputPeakL {0.0f}, outputPeakR {0.0f};
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (B808AirLabAudioProcessor)
};
