#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class B808AirLabAudioProcessorEditor final : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit B808AirLabAudioProcessorEditor (B808AirLabAudioProcessor&);
    ~B808AirLabAudioProcessorEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;
private:
    class DialLookAndFeel final : public juce::LookAndFeel_V4
    {
    public:
        void drawRotarySlider (juce::Graphics&, int, int, int, int, float, float, float, juce::Slider&) override;
    } look;
    B808AirLabAudioProcessor& processor;
    juce::Slider mid, high, trim, mix, input, analog;
    juce::ComboBox quality;
    juce::ToggleButton link { "LINK" }, bypass { "POWER" };
    juce::Label midLabel, highLabel, trimLabel, mixLabel, inputLabel, analogLabel, qualityLabel, subtitle;
    juce::Label midValue, highValue, trimValue, mixValue, inputValue, analogValue;
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    std::unique_ptr<SliderAttachment> midAttach, highAttach, trimAttach, mixAttach, inputAttach, analogAttach;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> qualityAttach;
    std::unique_ptr<ButtonAttachment> linkAttach, bypassAttach;
    bool linking = false;
    void timerCallback() override;
    void drawMeter (juce::Graphics&, juce::Rectangle<float>, float, const juce::String&);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (B808AirLabAudioProcessorEditor)
};
